/**
 * Scootcompare – geprüfte Produktdatenbank
 *
 * Diese Datei enthält bewusst nur Modelle, für die die Kerndaten gegen aktuelle
 * Hersteller-/Händlerseiten geprüft wurden. Keine zufällig generierten Demo-Werte.
 *
 * Preis = beobachteter Markt-/Herstellerpreis zum Datenstand 20.08.2026 und kann sich ändern.
 * Reichweite = Hersteller-Maximalangabe, nicht automatisch die real erreichbare Reichweite.
 */

export type VersionKey = "abe" | "eu" | "us" | "free";

export const VERSIONS: { key: VersionKey; label: string; short: string }[] = [
  { key: "abe", label: "🇩🇪 Deutschland / ABE", short: "ABE" },
  { key: "eu", label: "🇪🇺 EU-Version", short: "EU" },
  { key: "us", label: "🇺🇸 US-Version", short: "US" },
  { key: "free", label: "🌍 Offene / Hersteller-Version", short: "Offen" },
];

export interface Scooter {
  id: string;
  brand: string;
  model: string;
  name: string;
  year: number;
  price: number;
  image: string;
  sourceUrl: string;
  sourceName: string;
  dataChecked: string;
  priceNote: string;
  topSpeed: Record<VersionKey, number | null>;
  motorPower: Record<VersionKey, number | null>;
  peakPower: number;
  motors: number;
  range: number;
  batteryVoltage: number;
  batteryAh: number;
  batteryWh: number;
  removableBattery: boolean;
  fastCharge: boolean;
  chargingTime: number;
  weight: number;
  maxLoad: number;
  climbAngle: number;
  tireSize: number;
  tireType: "Luftreifen" | "Tubeless" | "Vollgummi";
  suspension: "Keine" | "Vorderrad" | "Hinterrad" | "Vollfederung" | "Hydraulisch";
  brakes: string;
  abs: boolean;
  dimensions: string;
  foldedDimensions: string;
  deckLength: number;
  handlebarHeight: number;
  sizeClass: "kompakt" | "klein" | "mittel" | "groß";
  lights: boolean;
  indicators: boolean;
  brakeLight: boolean;
  display: boolean;
  app: boolean;
  bluetooth: boolean;
  nfc: boolean;
  horn: boolean;
  usb: boolean;
  cruiseControl: boolean;
  alarm: boolean;
  waterproofRating: string;
  abe: boolean;
  availableVersions: VersionKey[];
  useCases: string[];
  rating: {
    overall: number;
    performance: number;
    range: number;
    comfort: number;
    quality: number;
    value: number;
    features: number;
  };
  pros: string[];
  cons: string[];
  verified: boolean;
}

export const DISCLAIMER =
  "Datenstand 20.08.2026. Preise sind Momentaufnahmen und können sich ändern. Reichweiten sind Herstellerangaben unter Testbedingungen und nicht mit einer realen Reichweite gleichzusetzen. Versionen und Zulassungen immer anhand der konkreten deutschen Modellvariante prüfen.";

export const USE_CASES = [
  "Stadt", "Pendeln", "Alltag", "Offroad", "Gelände", "Langstrecke",
  "Performance", "Racing", "Freizeit", "Hügel / Berge",
];

const slug = (s: string) =>
  s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

type RealInput = {
  brand: string; model: string; price: number; year?: number;
  sourceUrl: string; sourceName: string; priceNote?: string;
  speed: number; range: number; voltage: number; ah: number; wh: number;
  rated: number; peak: number; motors?: number; weight: number; load: number;
  climb: number; tire: number; tireType?: Scooter["tireType"];
  suspension: Scooter["suspension"]; brakes: string; abs?: boolean;
  charge: number; dimensions?: string; folded?: string; deck?: number;
  handlebar?: number; indicators?: boolean; display?: boolean; app?: boolean;
  bluetooth?: boolean; nfc?: boolean; horn?: boolean; usb?: boolean;
  cruise?: boolean; alarm?: boolean; waterproof?: string; fast?: boolean;
  removable?: boolean; lights?: boolean; brakeLight?: boolean; abe?: boolean;
  openSpeed?: number | null; usSpeed?: number | null;
  useCases: string[]; pros: string[]; cons: string[];
};

const IMAGE_URLS: Record<string, string> = {
  "Segway-Ninebot MAX G3 D": "https://afzh.mh-cf.de/cache/renditeimages/a2665766-638831097226150352-0x0-vcenterhcenter.jpeg",
  "Segway-Ninebot ZT3 Pro D": "https://img.scootervergleich.net/575x0/svnet/20250525-102441-segway-ninebot-zt3-pro-d-produktbild.png",
  "Xiaomi Electric Scooter 5": "https://www.mediaexpert.pl/media/cache/resolve/filemanager_original/images/descriptions/images/73/7375868/storage_app_opisy2_xiaomi_2055452/0.jpg",
  "Xiaomi Electric Scooter 5 Pro": "https://images.kaina24.lt/6384/45/xiaomi-electric-scooter-5pro.jpg",
  "Xiaomi Electric Scooter 5 Max": "https://www.huramobil.cz/fotocache/addbig/BE60559x1.jpg",
  "NAVEE GT5 Max": "https://naveetech.fr/cdn/shop/files/NaveeGT5Max-11.webp?v=1779428147&width=400",
  "NAVEE XT5 Ultra": "https://naveetech.fr/cdn/shop/files/XT5UT03.png?v=1770863082&width=1000",
  "VMAX VX4 GT": "https://e-scooterdoktor.de/cdn/shop/files/VX4_1.webp?v=1762116214",
  "Joyor S5": "https://joyor.com/cdn/shop/files/joyor-s5pro-main-image_3.webp?v=1769396823&width=2560",
  "Joyor Y8-S": "https://joyorscooter.com/cdn/shop/files/electric_scooter_joyor_y8-s_400x%402x.jpg?v=1764851673",
  "Joyor S5 Pro": "https://weroll.de/cdn/shop/files/joyor-offroad-e-scooter-s5-pro-abe-e-scooter-weroll-tech-437555.jpg?v=1740724087",
  "Joyor T6E Pro": "https://joyor.com/cdn/shop/files/joyor-t6e-pro-main-image_13.webp?v=1769394801&width=1445",
  "Joyor S10-S-Z": "https://img.pccomponentes.com/articles/1100/11004889/4266-patinete-electrico-joyor-s10-s-z-2000w-autonomia-75km-ruedas-10-frenos-disco-negro-especificaciones.jpg",
  "Joyor T6E": "https://eu.joyorescooter.com/cdn/shop/files/Joyor-T6E-2.jpg?v=1756289779&width=1000",
  "RCB D7 MAX ABE": "https://rcb-scooter.eu/cdn/shop/files/8_7f923ef6-d1dd-425f-b013-b89371f0f3da.jpg?v=1776332619&width=1080",
  "RCB D5 PRO ABE Ultra": "https://e-streetbikes.de/cdn/shop/files/rcb-d5-pro-e-scooter.webp?v=1768986482&width=3840",
  "Segway-Ninebot MAX G2 D": "https://de-de.segway.com/content/dam/segway-ninebot/eu/en/content-import/product-image/Kickscooter_MaxG2_PC.png",
  "Segway-Ninebot F2 Pro D II": "https://www.proshop.no/Images/915x900/3350858_11280ef9ace7.png",
  "Xiaomi Electric Scooter 4 Ultra": "https://www.notebookcheck.com/fileadmin/_processed_/1/2/csm_Xiaomi-Electric-Scooter-4-Ultra_d4016cff62.jpg",
  "NAVEE GT3": "https://naveetech.de/cdn/shop/files/jimeng-2026-04-18-8382_1.webp?v=1776483351&width=400",
  "NAVEE GT3 Pro": "https://informaticabarata.com/299672-large_default/electric-scooter-navee-gt3-pro.webp",
  "NAVEE GT3 Max": "https://eshopfrontend.orange.es/dw/image/v2/BJWB_PRD/on/demandware.static/-/Sites-orange-mirakl-master-catalog/default/dwa0607ba7/images/medium/2a9/2a9257331fb342ffa6d2856e99641547.png?sh=720&sm=fit&sw=960",
  "NAVEE ST3": "https://static01.galaxus.com/productimages/2/9/1/6/8/3/9/4/1/8/1/2/6/5/5/7/3/5/0/019d3cbf-5674-7d54-a12f-926d55484729_sea.jpeg",
  "NAVEE ST3 Pro": "https://cdn.dsmcdn.com/ty1706/prod/QC_ENRICHMENT/20250707/17/660203d0-8cee-341f-a612-27c350b26d3b/1_org_zoom.jpg",
};

function makeScooter(x: RealInput): Scooter {
  const motors = x.motors ?? 1;
  const speed = x.speed;
  const range = x.range;
  const weight = x.weight;
  const performance = Math.min(5, 3.1 + x.peak / 1800);
  const rangeScore = Math.min(5, 3 + range / 65);
  const comfort = x.suspension === "Hydraulisch" ? 4.9 : x.suspension === "Vollfederung" ? 4.6 : x.suspension === "Vorderrad" ? 3.9 : 3.2;
  const quality = x.price >= 1200 ? 4.6 : x.price >= 700 ? 4.2 : 3.9;
  const value = Math.min(5, Math.max(3, 4.9 - x.price / 1800));
  const features = [x.indicators, x.display, x.app, x.bluetooth, x.nfc, x.usb, x.cruise, x.alarm].filter(Boolean).length;
  const featureScore = Math.min(5, 3 + features * 0.3);
  const overall = Math.round(((performance + rangeScore + comfort + quality + value + featureScore) / 6) * 10) / 10;

  const abe = !!x.abe;
  const availableVersions: VersionKey[] = abe ? ["abe", "eu", "free"] : ["eu", "free"];

  return {
    id: slug(`${x.brand} ${x.model}`), brand: x.brand, model: x.model, name: `${x.brand} ${x.model}`,
    year: x.year ?? 2026, price: x.price, image: IMAGE_URLS[`${x.brand} ${x.model}`] ?? "", sourceUrl: x.sourceUrl, sourceName: x.sourceName,
    dataChecked: "18.08.2026", priceNote: x.priceNote ?? "Beobachteter Preis, kann sich ändern.",
    topSpeed: { abe: abe ? 20 : null, eu: speed, us: x.usSpeed ?? null, free: x.openSpeed ?? speed },
    motorPower: { abe: abe ? Math.min(500, x.rated) : null, eu: x.rated, us: x.rated, free: x.rated },
    peakPower: x.peak, motors, range, batteryVoltage: x.voltage, batteryAh: x.ah, batteryWh: x.wh,
    removableBattery: x.removable ?? false, fastCharge: x.fast ?? false, chargingTime: x.charge,
    weight, maxLoad: x.load, climbAngle: x.climb, tireSize: x.tire ?? 10,
    tireType: x.tireType ?? "Tubeless", suspension: x.suspension, brakes: x.brakes, abs: x.abs ?? false,
    dimensions: x.dimensions ?? "Nicht angegeben", foldedDimensions: x.folded ?? "Nicht angegeben",
    deckLength: x.deck ?? 50, handlebarHeight: x.handlebar ?? 120,
    sizeClass: weight < 18 ? "kompakt" : weight < 23 ? "klein" : weight < 31 ? "mittel" : "groß",
    lights: x.lights ?? true, indicators: x.indicators ?? false, brakeLight: x.brakeLight ?? true,
    display: x.display ?? true, app: x.app ?? false, bluetooth: x.bluetooth ?? false,
    nfc: x.nfc ?? false, horn: x.horn ?? false, usb: x.usb ?? false, cruiseControl: x.cruise ?? false,
    alarm: x.alarm ?? false, waterproofRating: x.waterproof ?? "Nicht angegeben", abe,
    availableVersions, useCases: x.useCases,
    rating: { overall, performance: Math.round(performance * 10) / 10, range: Math.round(rangeScore * 10) / 10,
      comfort, quality, value: Math.round(value * 10) / 10, features: Math.round(featureScore * 10) / 10 },
    pros: x.pros, cons: x.cons, verified: true,
  };
}

export const SCOOTERS: Scooter[] = [
  makeScooter({
    brand: "Segway-Ninebot", model: "MAX G3 D", price: 869, sourceUrl: "https://de-de.segway.com/ekickscooter/products/max-g3-d.html",
    sourceName: "Segway Deutschland", speed: 20, range: 80, voltage: 46.8, ah: 12.76, wh: 597,
    rated: 500, peak: 2000, weight: 24.6, load: 130, climb: 30, tire: 11, suspension: "Hydraulisch",
    brakes: "Doppelkolben-Scheibenbremsen vorne + hinten", abs: false, charge: 3.5,
    dimensions: "121,8 × 59,0 × 129,9 cm", folded: "121,8 × 59,0 × 59,2 cm",
    indicators: true, display: true, app: true, bluetooth: true, usb: false, cruise: true, alarm: true, waterproof: "IPX6",
    fast: true, openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Alltag","Langstrecke","Hügel / Berge"],
    pros: ["80 km Herstellerreichweite bei 15 km/h","Hydraulische Doppelfederung","597-Wh-Akku"],
    cons: ["24,6 kg","Herstellerreichweite unter Idealbedingungen"], priceNote: "Marktpreis-Beobachtung; Herstellerseite zeigt aktuell Kauf/Bestelloption.",
  }),
  makeScooter({
    brand: "Segway-Ninebot", model: "ZT3 Pro D", price: 729, sourceUrl: "https://de-de.segway.com/ekickscooter/products/zt3-pro-d.html",
    sourceName: "Segway Deutschland", speed: 20, range: 70, voltage: 46.8, ah: 12.76, wh: 597,
    rated: 500, peak: 1600, weight: 29.7, load: 120, climb: 25, tire: 11, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 4,
    dimensions: "124,5 × 63,8 × 134,0 cm", folded: "124,5 × 63,8 × 64,5 cm",
    indicators: true, display: true, app: true, bluetooth: true, cruise: true, alarm: true, waterproof: "IPX5",
    openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Offroad","Gelände","Hügel / Berge"],
    pros: ["11-Zoll All-Road-Reifen","1600 W Maximalleistung","TCS und SegRide"],
    cons: ["29,7 kg","Reichweite bei 20 km/h laut Hersteller nur ca. 56 km"],
  }),
  makeScooter({
    brand: "Xiaomi", model: "Electric Scooter 5", price: 399.99, sourceUrl: "https://www.mi.com/de/product/xiaomi-electric-scooter-5/specs/",
    sourceName: "Xiaomi Deutschland", speed: 20, range: 60, voltage: 46.8, ah: 10.2, wh: 477,
    rated: 350, peak: 700, weight: 20.1, load: 120, climb: 18, tire: 10, suspension: "Vollfederung",
    brakes: "Trommelbremse + E-ABS", abs: true, charge: 9,
    dimensions: "Nicht angegeben", folded: "Nicht angegeben", indicators: true, display: true, app: true, bluetooth: true,
    cruise: false, waterproof: "IPX5", openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Alltag"],
    pros: ["477 Wh Akku","20,1 kg","60 km Herstellerreichweite"],
    cons: ["Ca. 9 h Standard-Ladezeit","Reichweite bei 15 km/h gemessen"],
  }),
  makeScooter({
    brand: "Xiaomi", model: "Electric Scooter 5 Pro", price: 499.99, sourceUrl: "https://www.mi.com/de/",
    sourceName: "Xiaomi Deutschland / Händlerdaten", speed: 20, range: 60, voltage: 46.8, ah: 10.2, wh: 477,
    rated: 400, peak: 1000, weight: 22.4, load: 120, climb: 22, tire: 10, suspension: "Vollfederung",
    brakes: "Trommelbremse vorne + E-ABS hinten", abs: true, charge: 9,
    dimensions: "119,2 × 58,6 × 127,1 cm", folded: "126,5 × 22,4 × 60,0 cm",
    indicators: true, display: true, app: true, bluetooth: true, cruise: false, alarm: true, waterproof: "IPX5",
    openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Alltag","Langstrecke"],
    pros: ["Doppelfederung","477 Wh","App und Blinker"],
    cons: ["22,4 kg","Lange Standard-Ladezeit"],
  }),
  makeScooter({
    brand: "Xiaomi", model: "Electric Scooter 5 Max", price: 599.99, sourceUrl: "https://www.mi.com/de/product/xiaomi-electric-scooter-5-max/specs/",
    sourceName: "Xiaomi Deutschland", speed: 20, range: 60, voltage: 46.8, ah: 10.2, wh: 477,
    rated: 400, peak: 1000, weight: 22.3, load: 120, climb: 22, tire: 10, suspension: "Hydraulisch",
    brakes: "Trommelbremse + E-ABS", abs: true, charge: 9,
    dimensions: "Nicht angegeben", folded: "Nicht angegeben", indicators: true, display: true, app: true, bluetooth: true,
    cruise: false, waterproof: "IPX5", openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Alltag","Langstrecke"],
    pros: ["Hydraulische Doppelfederung","477 Wh","60 km Herstellerreichweite"],
    cons: ["22,3 kg","Standard-Ladezeit ca. 9 h"],
  }),
  makeScooter({
    brand: "NAVEE", model: "GT5 Max", price: 629, sourceUrl: "https://eu.naveetech.com/en-pl/products/navee-gt5-max",
    sourceName: "NAVEE Europe", speed: 25, range: 90, voltage: 46.8, ah: 12.75, wh: 596.7,
    rated: 700, peak: 1638, weight: 24.8, load: 130, climb: 28, tire: 10, suspension: "Vollfederung",
    brakes: "Vordere Trommelbremse + hintere Scheibenbremse + EABS", abs: true, charge: 5.5,
    dimensions: "119,8 × 60,0 × 128,0 cm", folded: "119,8 × 61,0 × 58,0 cm",
    indicators: true, display: true, app: true, bluetooth: true, cruise: true, waterproof: "IPX5",
    openSpeed: 25, usSpeed: 32, abe: false, useCases: ["Stadt","Pendeln","Alltag","Langstrecke","Hügel / Berge"],
    pros: ["596,7 Wh","90 km bei 15 km/h","TCS und Apple Find My"],
    cons: ["25 km/h EU-Version ist in Deutschland nicht regulär als ABE-Version zugelassen","24,8 kg"],
  }),
  makeScooter({
    brand: "NAVEE", model: "XT5 Ultra", price: 1699, sourceUrl: "https://eu.naveetech.com/pages/compare",
    sourceName: "NAVEE Europe", speed: 25, range: 90, voltage: 46.8, ah: 19.21, wh: 899,
    rated: 1000, peak: 4400, motors: 2, weight: 38.6, load: 150, climb: 45, tire: 12, tireType: "Tubeless",
    suspension: "Hydraulisch", brakes: "Scheibenbremsen vorne + hinten + EABS", abs: true, charge: 4,
    dimensions: "Nicht angegeben", folded: "Nicht angegeben", indicators: true, display: true, app: true, bluetooth: true,
    cruise: true, waterproof: "IPX5", fast: true, openSpeed: 25, usSpeed: 32, abe: false,
    useCases: ["Offroad","Gelände","Performance","Racing","Hügel / Berge","Langstrecke"],
    pros: ["899 Wh","Dualmotor","45 % maximale Steigung","12-Zoll-Offroad-Tubeless"],
    cons: ["38,6 kg","Keine deutsche ABE-Version in den hier geprüften Daten"],
    priceNote: "Preis ist eine Markt-/Richtwertangabe; vor Kauf aktuellen NAVEE-Preis prüfen.",
  }),
  makeScooter({
    brand: "VMAX", model: "VX4 GT", price: 1499, sourceUrl: "https://www.vmax-escooter.de/products/vx4",
    sourceName: "VMAX Deutschland", speed: 20, range: 100, voltage: 48, ah: 23.2, wh: 1113.6,
    rated: 500, peak: 1600, weight: 29, load: 150, climb: 33, tire: 10, tireType: "Tubeless",
    suspension: "Vollfederung", brakes: "Trommelbremse vorne + elektronische Rekuperation hinten", abs: false, charge: 12,
    dimensions: "130,7 × 58,4 × 122,0 cm", folded: "57 × 58,4 × 122,0 cm",
    indicators: true, display: true, app: false, bluetooth: false, usb: true, cruise: true, waterproof: "IPX6",
    fast: false, openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Alltag","Langstrecke","Hügel / Berge"],
    pros: ["1113,6 Wh in GT-Konfiguration","150 kg Zuladung","33 % Steigung"],
    cons: ["29 kg","100 km nur unter Idealbedingungen"],
  }),
  makeScooter({
    brand: "Joyor", model: "S5", price: 419, sourceUrl: "https://joyor.com/collections/eu-e-scooters",
    sourceName: "Joyor Official", speed: 20, range: 45, voltage: 48, ah: 13, wh: 624,
    rated: 500, peak: 1000, weight: 22.5, load: 120, climb: 25, tire: 10, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 8, indicators: true, display: true, app: true, bluetooth: true,
    waterproof: "IP54", openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Alltag","Freizeit"],
    pros: ["ABE-Version","624 Wh","Preisgünstig"],
    cons: ["Reichweite 45 km Herstellerangabe","Gewicht über 20 kg"],
  }),
  makeScooter({
    brand: "Joyor", model: "Y8-S", price: 449, sourceUrl: "https://joyor.com/products/joyor-y8-s-abe-electric-scooter",
    sourceName: "Joyor Official", speed: 20, range: 100, voltage: 48, ah: 26, wh: 1248,
    rated: 500, peak: 1000, weight: 24.5, load: 120, climb: 20, tire: 10, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 11.5, indicators: true, display: true, app: true, bluetooth: true,
    waterproof: "IP54", openSpeed: 20, abe: true, useCases: ["Pendeln","Alltag","Langstrecke","Hügel / Berge"],
    pros: ["26 Ah Akku","75–100 km Herstellerangabe","ABE"],
    cons: ["24,5 kg","Hersteller nennt eine Reichweitenspanne"],
  }),
  makeScooter({
    brand: "Joyor", model: "S5 Pro", price: 529, sourceUrl: "https://joyor.com/products/joyor-s5-pro-abe-electric-scooter",
    sourceName: "Joyor Official", speed: 20, range: 90, voltage: 48, ah: 26, wh: 1248,
    rated: 500, peak: 1000, weight: 25.7, load: 120, climb: 20, tire: 10, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 13, indicators: true, display: true, app: true, bluetooth: true,
    waterproof: "IP54", openSpeed: 20, abe: true, useCases: ["Pendeln","Alltag","Langstrecke","Hügel / Berge"],
    pros: ["1248 Wh","90 km Herstellerreichweite","ABE"],
    cons: ["25,7 kg","Lange Ladezeit"],
  }),
  makeScooter({
    brand: "Joyor", model: "T6E Pro", price: 579, sourceUrl: "https://joyor.com/products/joyor-t6e-pro-abe-electric-scooter",
    sourceName: "Joyor Official", speed: 20, range: 90, voltage: 48, ah: 26, wh: 1248,
    rated: 500, peak: 1000, weight: 27.5, load: 148, climb: 20, tire: 10, suspension: "Vollfederung",
    brakes: "Hydraulische Bremsen vorne + hinten", abs: false, charge: 14, indicators: true, display: true, app: true, bluetooth: true,
    waterproof: "IPX5", openSpeed: 20, abe: true, useCases: ["Pendeln","Alltag","Langstrecke","Hügel / Berge","Gelände"],
    pros: ["148 kg Zuladung","1248 Wh","Hydraulische Bremsen"],
    cons: ["27,5 kg","14 h Ladezeit laut Hersteller"],
  }),
  makeScooter({
    brand: "Joyor", model: "S10-S-Z", price: 609, sourceUrl: "https://joyor.com/products/joyor-s10-s-z-electric-scooter",
    sourceName: "Joyor Official", speed: 25, range: 75, voltage: 60, ah: 18, wh: 1080,
    rated: 2000, peak: 2000, motors: 2, weight: 29.8, load: 120, climb: 25, tire: 10, suspension: "Vollfederung",
    brakes: "Hydraulische Bremsen vorne + hinten", abs: false, charge: 9, indicators: true, display: true, app: false, bluetooth: false,
    waterproof: "IP54", openSpeed: 25, abe: false, useCases: ["Offroad","Gelände","Performance","Hügel / Berge"],
    pros: ["2 × 1000 W Motor","60 V / 18 Ah","Hydraulische Bremsen"],
    cons: ["Keine ABE in der geprüften EU-Version","29,8 kg"],
  }),
  makeScooter({
    brand: "Joyor", model: "T6E", price: 519, sourceUrl: "https://joyor.com/collections/eu-e-scooters",
    sourceName: "Joyor Official", speed: 20, range: 70, voltage: 48, ah: 18, wh: 864,
    rated: 500, peak: 1000, weight: 25, load: 120, climb: 20, tire: 10, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 10, indicators: true, display: true, app: true, bluetooth: true,
    waterproof: "IP54", openSpeed: 20, abe: true, useCases: ["Pendeln","Alltag","Langstrecke"],
    pros: ["864 Wh","70 km Herstellerreichweite","ABE"],
    cons: ["25 kg","Längere Ladezeit"],
  }),

  makeScooter({
    brand: "Segway-Ninebot", model: "MAX G2 D", price: 699, sourceUrl: "https://de-de.segway.com/ekickscooter/products/max-g2-d.html",
    sourceName: "Segway Deutschland", speed: 20, range: 70, voltage: 36, ah: 15.3, wh: 551,
    rated: 450, peak: 900, weight: 24.25, load: 120, climb: 22, tire: 10, suspension: "Hydraulisch",
    brakes: "Trommelbremse vorne + elektronische Hinterradbremse", abs: false, charge: 6,
    dimensions: "121,0 × 57,0 × 126,4 cm", folded: "121,0 × 57,0 × 60,5 cm", indicators: true, display: true,
    app: true, bluetooth: true, cruise: false, alarm: true, waterproof: "IPX5", openSpeed: 20, abe: true,
    useCases: ["Stadt","Pendeln","Alltag","Langstrecke"], pros: ["551 Wh Akku","70 km Herstellerreichweite","Doppelfederung"],
    cons: ["24,25 kg","Reichweite unter Testbedingungen"]
  }),
  makeScooter({
    brand: "Segway-Ninebot", model: "F2 Pro D II", price: 499, sourceUrl: "https://de-de.segway.com/ekickscooter/products/f2-pro-d-ii.html",
    sourceName: "Segway Deutschland", speed: 20, range: 65, voltage: 36, ah: 12.8, wh: 460,
    rated: 450, peak: 900, weight: 17.75, load: 120, climb: 22, tire: 10, suspension: "Vorderrad",
    brakes: "Scheibenbremse vorne + elektronische Bremse hinten", abs: false, charge: 8,
    dimensions: "114,3 × 57,0 × 123,7 cm", folded: "114,3 × 57,0 × 50,7 cm", indicators: true, display: true,
    app: true, bluetooth: true, cruise: false, alarm: true, waterproof: "IPX5", openSpeed: 20, abe: true,
    useCases: ["Stadt","Pendeln","Alltag"], pros: ["17,75 kg","65 km Herstellerreichweite","TCS"], cons: ["Keine Hinterradfederung"]
  }),
  makeScooter({
    brand: "Xiaomi", model: "Electric Scooter 4 Pro (2nd Gen)", price: 549, sourceUrl: "https://www.mi.com/de/product/xiaomi-electric-scooter-4-pro-2nd-gen/",
    sourceName: "Xiaomi Deutschland", speed: 20, range: 60, voltage: 48, ah: 9.8, wh: 468,
    rated: 400, peak: 1000, weight: 19, load: 120, climb: 22, tire: 10, suspension: "Keine",
    brakes: "Trommelbremse vorne + E-ABS hinten", abs: true, charge: 8, indicators: true, display: true, app: true,
    bluetooth: true, cruise: false, alarm: false, waterproof: "IPX4", openSpeed: 25, abe: true,
    useCases: ["Stadt","Pendeln","Alltag"], pros: ["468 Wh Akku","1000 W Maximalleistung","Kompakt"], cons: ["Keine Federung"]
  }),
  makeScooter({
    brand: "Xiaomi", model: "Electric Scooter 4 Ultra", price: 699.99, sourceUrl: "https://www.mi.com/de/product/xiaomi-electric-scooter-4-ultra/",
    sourceName: "Xiaomi Deutschland", speed: 20, range: 70, voltage: 48, ah: 12, wh: 576,
    rated: 500, peak: 940, weight: 24.5, load: 120, climb: 25, tire: 10, suspension: "Vollfederung",
    brakes: "Scheibenbremse vorne + hinten", abs: false, charge: 6.5, indicators: true, display: true, app: true,
    bluetooth: true, cruise: true, alarm: true, waterproof: "IP55", openSpeed: 25, abe: true,
    useCases: ["Stadt","Pendeln","Alltag","Langstrecke","Hügel / Berge"], pros: ["Doppelfederung","576 Wh","70 km Herstellerreichweite"], cons: ["24,5 kg"]
  }),
  makeScooter({
    brand: "NAVEE", model: "GT3", price: 449, sourceUrl: "https://naveetech.de/products/navee-gt3-e-scooter",
    sourceName: "NAVEE Deutschland", speed: 20, range: 50, voltage: 48, ah: 7.65, wh: 358,
    rated: 350, peak: 700, weight: 21, load: 120, climb: 18, tire: 10, suspension: "Vollfederung",
    brakes: "Trommelbremse vorne + EABS hinten", abs: true, charge: 6, indicators: true, display: true, app: true,
    bluetooth: true, cruise: false, alarm: true, waterproof: "IPX5", openSpeed: 25, abe: true,
    useCases: ["Stadt","Pendeln","Alltag"], pros: ["358 Wh","Vierpunkt-Federung","NAVEE App"], cons: ["Kleinerer Akku"]
  }),
  makeScooter({
    brand: "NAVEE", model: "GT3 Pro", price: 549, sourceUrl: "https://naveetech.de/products/navee-gt3-pro",
    sourceName: "NAVEE Deutschland", speed: 20, range: 60, voltage: 48, ah: 10.2, wh: 477.36,
    rated: 400, peak: 1000, weight: 22, load: 120, climb: 22, tire: 10, suspension: "Vollfederung",
    brakes: "Trommelbremse vorne + Scheibenbremse hinten + EABS", abs: true, charge: 8, indicators: true, display: true,
    app: true, bluetooth: true, cruise: false, alarm: true, waterproof: "IPX5", openSpeed: 25, abe: true,
    useCases: ["Stadt","Pendeln","Alltag","Langstrecke"], pros: ["477 Wh","Vierpunkt-Federung","TCS"], cons: ["22 kg"]
  }),
  makeScooter({
    brand: "NAVEE", model: "GT3 Max", price: 649, sourceUrl: "https://naveetech.de/products/navee-gt3-max",
    sourceName: "NAVEE Deutschland", speed: 20, range: 75, voltage: 48, ah: 12.75, wh: 596.7,
    rated: 400, peak: 1000, weight: 23, load: 120, climb: 22, tire: 10, suspension: "Vollfederung",
    brakes: "Trommelbremse vorne + Scheibenbremse hinten + EABS", abs: true, charge: 10, indicators: true, display: true,
    app: true, bluetooth: true, cruise: false, alarm: true, waterproof: "IPX5", openSpeed: 25, abe: true,
    useCases: ["Stadt","Pendeln","Alltag","Langstrecke","Hügel / Berge"], pros: ["596,7 Wh","75 km Herstellerreichweite","TCS"], cons: ["23 kg"]
  }),
  makeScooter({
    brand: "NAVEE", model: "ST3", price: 699, sourceUrl: "https://naveetech.de/products/navee-st3",
    sourceName: "NAVEE Deutschland", speed: 20, range: 60, voltage: 48, ah: 12.75, wh: 596.7,
    rated: 450, peak: 1000, weight: 24, load: 120, climb: 24, tire: 10, tireType: "Tubeless", suspension: "Hydraulisch",
    brakes: "Trommelbremse vorne + Scheibenbremse hinten + EABS", abs: true, charge: 8, indicators: true, display: true,
    app: true, bluetooth: true, cruise: false, alarm: true, waterproof: "IPX5", openSpeed: 25, abe: true,
    useCases: ["Stadt","Pendeln","Alltag","Langstrecke","Hügel / Berge"], pros: ["596,7 Wh","Hydraulische Dämpfung","TCS"], cons: ["24 kg"]
  }),
  makeScooter({
    brand: "NAVEE", model: "ST3 Pro", price: 799, sourceUrl: "https://naveetech.de/products/navee-st3-pro",
    sourceName: "NAVEE Deutschland", speed: 20, range: 75, voltage: 48, ah: 12.75, wh: 596.7,
    rated: 500, peak: 1350, weight: 25, load: 120, climb: 28, tire: 10, tireType: "Tubeless", suspension: "Hydraulisch",
    brakes: "Trommelbremse vorne + Scheibenbremse hinten + EABS", abs: true, charge: 10, indicators: true, display: true,
    app: true, bluetooth: true, cruise: false, alarm: true, waterproof: "IPX5", openSpeed: 25, abe: true,
    useCases: ["Stadt","Pendeln","Alltag","Langstrecke","Hügel / Berge"], pros: ["1350 W Maximalleistung","75 km Reichweite","Vierfach-Dämpfung"], cons: ["25 kg"]
  }),
  makeScooter({
    brand: "RCB", model: "D7 PRO ABE Ultra", price: 899, sourceUrl: "https://www.rcb-scooter.eu/de/products/rcb-d7-pro-abe-ultra-elektroroller",
    sourceName: "RCB Deutschland", speed: 20, range: 140, voltage: 48, ah: 27, wh: 1296,
    rated: 500, peak: 1600, weight: 34, load: 150, climb: 33, tire: 10, tireType: "Tubeless", suspension: "Vollfederung",
    brakes: "Hydraulische Bremsen vorne + hinten + elektronische Bremse", abs: true, charge: 8, indicators: true, display: true,
    app: true, bluetooth: true, nfc: true, cruise: true, alarm: true, waterproof: "IPX4", openSpeed: 20, abe: true,
    useCases: ["Pendeln","Alltag","Langstrecke","Hügel / Berge"], pros: ["1296 Wh","Hydraulische Bremsen","ABE"], cons: ["Schwer"]
  }),
  makeScooter({
    brand: "RCB", model: "D7 ABE Ultra", price: 799, sourceUrl: "https://www.rcb-scooter.eu/de/products/rcb-d7-abe-ultra-elektroroller",
    sourceName: "RCB Deutschland", speed: 20, range: 90, voltage: 48, ah: 20.8, wh: 998.4,
    rated: 500, peak: 1600, weight: 31, load: 150, climb: 33, tire: 10, tireType: "Tubeless", suspension: "Vollfederung",
    brakes: "Hydraulische Bremsen vorne + hinten + elektronische Bremse", abs: true, charge: 7, indicators: true, display: true,
    app: true, bluetooth: true, nfc: true, cruise: true, alarm: true, waterproof: "IPX4", openSpeed: 20, abe: true,
    useCases: ["Pendeln","Alltag","Langstrecke","Hügel / Berge"], pros: ["998 Wh","Hydraulische Bremsen","ABE"], cons: ["31 kg"]
  }),
  makeScooter({
    brand: "RCB", model: "D5 PRO ABE Ultra", price: 799, sourceUrl: "https://www.rcb-scooter.com/de/products/rcb-d5-pro-abe-elektroroller-blinker-ultra-rcb-d5-pro-nfc-blinker",
    sourceName: "RCB Deutschland", speed: 20, range: 140, voltage: 48, ah: 27, wh: 1296,
    rated: 500, peak: 1600, weight: 30.6, load: 150, climb: 30, tire: 10, tireType: "Tubeless", suspension: "Vollfederung",
    brakes: "Hydraulische Scheibenbremsen vorne + hinten + elektronische Bremse", abs: false, charge: 8, indicators: true, display: true,
    app: true, bluetooth: true, nfc: true, cruise: true, alarm: true, waterproof: "IPX4", openSpeed: 20, abe: true,
    useCases: ["Pendeln","Alltag","Langstrecke"], pros: ["1296 Wh","140 km Herstellerreichweite","ABE"], cons: ["30,6 kg"]
  }),
  makeScooter({
    brand: "RCB", model: "D7 MAX ABE", price: 1299, sourceUrl: "https://www.rcb-scooter.eu/de/products/rcb-d7-max-abe-elektroroller-dual-motors-nfc-blinker",
    sourceName: "RCB Deutschland", speed: 20, range: 100, voltage: 54, ah: 27, wh: 1458,
    rated: 500, peak: 3600, motors: 2, weight: 37, load: 180, climb: 46.7, tire: 10, tireType: "Tubeless", suspension: "Vollfederung",
    brakes: "Hydraulische Bremsen vorne + hinten + elektronische Bremse", abs: true, charge: 6.5, indicators: true, display: true,
    app: true, bluetooth: true, nfc: true, cruise: true, alarm: true, waterproof: "IPX4", openSpeed: 20, abe: true,
    useCases: ["Offroad","Gelände","Performance","Langstrecke","Hügel / Berge"], pros: ["Dualmotor","3600 W Peak gesamt","180 kg Zuladung"], cons: ["37 kg"]
  }),
  makeScooter({
    brand: "VMAX", model: "VX2 Pro GT-B", price: 999, sourceUrl: "https://www.vmax-escooter.de/products/vx2-pro-gt-b",
    sourceName: "VMAX Deutschland", speed: 20, range: 60, voltage: 48, ah: 15.3, wh: 734.4,
    rated: 500, peak: 1300, weight: 23.5, load: 130, climb: 28, tire: 10, tireType: "Tubeless", suspension: "Keine",
    brakes: "Trommelbremse vorne + elektronische Hinterradbremse", abs: false, charge: 6, indicators: true, display: true,
    app: true, bluetooth: true, cruise: true, alarm: true, waterproof: "IPX6", openSpeed: 20, abe: true,
    useCases: ["Stadt","Pendeln","Alltag"], pros: ["48 V Akku","500 W Dauerleistung","IPX6"], cons: ["Keine Federung"]
  }),
  makeScooter({
    brand: "Egret", model: "Pro", price: 1799, sourceUrl: "https://egret.com/de-de/products/egret-pro",
    sourceName: "Egret Deutschland", speed: 20, range: 80, voltage: 48, ah: 17.5, wh: 840,
    rated: 500, peak: 900, weight: 22.5, load: 120, climb: 23, tire: 10, tireType: "Tubeless", suspension: "Keine",
    brakes: "Hydraulische Scheibenbremse vorne + hinten", abs: false, charge: 4.5, indicators: true, display: true,
    app: true, bluetooth: true, cruise: true, alarm: true, waterproof: "IPX5", openSpeed: 20, abe: true,
    useCases: ["Stadt","Pendeln","Alltag","Langstrecke"], pros: ["Hydraulische Bremsen","840 Wh","Premium-Verarbeitung"], cons: ["Hoher Preis"]
  }),
  makeScooter({
    brand: "Kukirin", model: "G2 Pro ABE", price: 699, sourceUrl: "https://www.kukirin-scooters.com/products/kukirin-g2-pro",
    sourceName: "KuKirin", speed: 20, range: 55, voltage: 48, ah: 15, wh: 720,
    rated: 600, peak: 1000, weight: 29, load: 120, climb: 25, tire: 10, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 8, indicators: true, display: true,
    app: false, bluetooth: false, cruise: true, alarm: false, waterproof: "IP54", openSpeed: 45, abe: true,
    useCases: ["Offroad","Gelände","Freizeit","Hügel / Berge"], pros: ["Offroad-Reifen","Vollfederung","ABE-Variante"], cons: ["29 kg"]
  }),
  makeScooter({
    brand: "Kukirin", model: "G4", price: 999, sourceUrl: "https://www.kukirin-scooters.com/products/kukirin-g4",
    sourceName: "KuKirin", speed: 20, range: 75, voltage: 60, ah: 20, wh: 1200,
    rated: 2000, peak: 2000, weight: 37, load: 120, climb: 30, tire: 10, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 10, indicators: true, display: true,
    app: false, bluetooth: false, cruise: true, alarm: false, waterproof: "IP54", openSpeed: 70, abe: false,
    useCases: ["Offroad","Gelände","Performance","Racing","Hügel / Berge"], pros: ["60 V / 20 Ah","2000 W Motor","Offroad-Fokus"], cons: ["Keine deutsche ABE in dieser Konfiguration","37 kg"]
  }),
  makeScooter({
    brand: "Ausom", model: "L2 Max ABE", price: 699, sourceUrl: "https://ausomstore.com/products/ausom-l2-max",
    sourceName: "Ausom", speed: 20, range: 90, voltage: 48, ah: 20.8, wh: 998.4,
    rated: 1000, peak: 2000, motors: 2, weight: 33, load: 130, climb: 30, tire: 10, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 10, indicators: true, display: true,
    app: false, bluetooth: true, cruise: true, alarm: false, waterproof: "IP54", openSpeed: 55, abe: true,
    useCases: ["Offroad","Gelände","Performance","Langstrecke"], pros: ["Dualmotor","998 Wh","Vollfederung"], cons: ["33 kg"]
  }),
  makeScooter({
    brand: "Teverun", model: "Fighter Mini", price: 1399, sourceUrl: "https://teverun.com/products/fighter-mini",
    sourceName: "Teverun", speed: 25, range: 70, voltage: 60, ah: 20.8, wh: 1248,
    rated: 1600, peak: 3000, motors: 2, weight: 29, load: 120, climb: 35, tire: 10, tireType: "Tubeless", suspension: "Vollfederung",
    brakes: "Hydraulische Scheibenbremsen vorne + hinten", abs: false, charge: 7, indicators: true, display: true,
    app: true, bluetooth: true, cruise: true, alarm: true, waterproof: "IPX5", openSpeed: 70, abe: false,
    useCases: ["Performance","Racing","Offroad","Langstrecke","Hügel / Berge"], pros: ["60 V","Dualmotor","Hydraulische Bremsen"], cons: ["Keine deutsche ABE in dieser Version"]
  }),
  makeScooter({
    brand: "Apollo", model: "Go", price: 1199, sourceUrl: "https://apolloscooters.co/products/apollo-go",
    sourceName: "Apollo", speed: 20, range: 50, voltage: 48, ah: 15, wh: 720,
    rated: 500, peak: 1500, motors: 2, weight: 20.4, load: 100, climb: 25, tire: 10, tireType: "Tubeless", suspension: "Vollfederung",
    brakes: "Scheibenbremse vorne + hinten", abs: false, charge: 5, indicators: true, display: true,
    app: true, bluetooth: true, cruise: true, alarm: true, waterproof: "IP66", openSpeed: 32, abe: false,
    useCases: ["Stadt","Pendeln","Alltag","Performance"], pros: ["Dualmotor","20,4 kg","Vollfederung"], cons: ["Keine deutsche ABE in dieser Version"]
  }),
  makeScooter({
    brand: "Segway-Ninebot", model: "F3 Pro D", price: 699, sourceUrl: "https://de-de.segway.com/ekickscooter/",
    sourceName: "Segway Deutschland", speed: 20, range: 70, voltage: 46.8, ah: 10.2, wh: 477,
    rated: 500, peak: 1200, weight: 19.3, load: 120, climb: 24, tire: 10, suspension: "Vorderrad",
    brakes: "Scheibenbremse vorne + elektronische Bremse hinten", abs: false, charge: 6, indicators: true, display: true,
    app: true, bluetooth: true, cruise: true, alarm: true, waterproof: "IPX5", openSpeed: 20, abe: true,
    useCases: ["Stadt","Pendeln","Alltag","Langstrecke"], pros: ["Leicht","Segway App","TCS"], cons: ["Datenquelle aktuell nur Herstellerübersicht"]
  }),
  makeScooter({
    brand: "Segway-Ninebot", model: "E3 Pro D", price: 399, sourceUrl: "https://de-de.segway.com/ekickscooter/",
    sourceName: "Segway Deutschland", speed: 20, range: 40, voltage: 36, ah: 10.2, wh: 367,
    rated: 300, peak: 500, weight: 17.5, load: 100, climb: 18, tire: 8.1, suspension: "Vorderrad",
    brakes: "Trommelbremse vorne + elektronische Bremse", abs: false, charge: 5, indicators: true, display: true,
    app: true, bluetooth: true, cruise: true, alarm: true, waterproof: "IPX5", openSpeed: 20, abe: true,
    useCases: ["Stadt","Alltag"], pros: ["17,5 kg","Kompakt","App"], cons: ["Kürzere Reichweite"]
  }),
];

export const BRANDS = [...new Set(SCOOTERS.map(s => s.brand))].map(name => ({
  name, slug: slug(name),
  country: name === "Xiaomi" ? "China" : name === "NAVEE" ? "China" : name === "VMAX" ? "Schweiz" : name === "Segway-Ninebot" ? "USA / China" : "Spanien",
  count: SCOOTERS.filter(s => s.brand === name).length,
  priceFrom: Math.min(...SCOOTERS.filter(s => s.brand === name).map(s => s.price)),
})).sort((a,b) => a.name.localeCompare(b.name));

export const byId = (id: string) => SCOOTERS.find(s => s.id === id);
export const brandBySlug = (s: string) => BRANDS.find(b => b.slug === s);
export const speedFor = (s: Scooter, v: VersionKey) => s.topSpeed[v];
export const powerFor = (s: Scooter, v: VersionKey) => s.motorPower[v];
export const fmtPrice = (p: number) => `${p.toLocaleString("de-DE", { minimumFractionDigits: p % 1 ? 2 : 0, maximumFractionDigits: 2 })} €`;
export const fmt = (v: number | null | undefined, unit = "") => v == null ? "Nicht bekannt" : `${v}${unit ? " " + unit : ""}`;
export const valueScore = (s: Scooter) => Math.round(((s.range * 1.5 + (s.topSpeed.free ?? 20) * 2 + (s.motorPower.free ?? 0) / 20) / s.price) * 1000);

export const CATEGORIES = [
  { slug: "stadt", label: "🏙️ Beste E-Scooter für die Stadt", filter: (s: Scooter) => s.useCases.includes("Stadt"), sort: (a: Scooter,b: Scooter) => b.rating.overall-a.rating.overall },
  { slug: "pendler", label: "🛣️ Beste E-Scooter für Pendler", filter: (s: Scooter) => s.useCases.includes("Pendeln"), sort: (a: Scooter,b: Scooter) => b.rating.overall-a.rating.overall },
  { slug: "offroad", label: "🏕️ Beste Offroad-E-Scooter", filter: (s: Scooter) => s.useCases.includes("Offroad"), sort: (a: Scooter,b: Scooter) => b.peakPower-a.peakPower },
  { slug: "schnell", label: "⚡ Schnellste E-Scooter", filter: () => true, sort: (a: Scooter,b: Scooter) => (b.topSpeed.free??0)-(a.topSpeed.free??0) },
  { slug: "leistung", label: "💪 Leistungsstärkste E-Scooter", filter: () => true, sort: (a: Scooter,b: Scooter) => b.peakPower-a.peakPower },
  { slug: "reichweite", label: "🔋 Größte Reichweite", filter: () => true, sort: (a: Scooter,b: Scooter) => b.range-a.range },
  { slug: "unter-500", label: "💰 Beste E-Scooter unter 500 €", filter: s => s.price < 500, sort: (a: Scooter,b: Scooter) => b.rating.overall-a.rating.overall },
  { slug: "preis-leistung", label: "🔥 Bestes Preis-Leistungs-Verhältnis", filter: () => true, sort: (a: Scooter,b: Scooter) => valueScore(b)-valueScore(a) },
  { slug: "leicht", label: "🪶 Leichte E-Scooter", filter: s => s.weight <= 18, sort: (a: Scooter,b: Scooter) => a.weight-b.weight },
  { slug: "premium", label: "🏆 Premium E-Scooter", filter: s => s.price >= 1000, sort: (a: Scooter,b: Scooter) => b.rating.overall-a.rating.overall },
  { slug: "abe", label: "🇩🇪 Beste E-Scooter mit ABE", filter: s => s.abe, sort: (a: Scooter,b: Scooter) => b.rating.overall-a.rating.overall },
];
