/**
 * Scootcompare – geprüfte Produktdatenbank
 *
 * Diese Datei enthält bewusst nur Modelle, für die die Kerndaten gegen aktuelle
 * Hersteller-/Händlerseiten geprüft wurden. Keine zufällig generierten Demo-Werte.
 *
 * Preis = beobachteter Preis zum Datenstand 18.08.2026 und kann sich ändern.
 * Reichweite = Hersteller-Maximalangabe, nicht automatisch die real erreichbare Reichweite.
 */

export type VersionKey = "abe" | "eu" | "us" | "free";

export const VERSIONS: { key: VersionKey; label: string; short: string }[] = [
  { key: "abe", label: "🇩🇪 Deutschland / ABE", short: "ABE" },
  { key: "eu", label: "🇪🇺 EU-Version", short: "EU" },
  { key: "us", label: "🇺🇸 US-Version", short: "US" },
  { key: "free", label: "🌍 Offene / Hersteller-Version", short: "Offen" },
];

export interface Scooter {
  id: string;
  brand: string;
  model: string;
  name: string;
  year: number;
  price: number;
  image: string;
  sourceUrl: string;
  sourceName: string;
  dataChecked: string;
  priceNote: string;
  topSpeed: Record<VersionKey, number | null>;
  motorPower: Record<VersionKey, number | null>;
  peakPower: number;
  motors: number;
  range: number;
  batteryVoltage: number;
  batteryAh: number;
  batteryWh: number;
  removableBattery: boolean;
  fastCharge: boolean;
  chargingTime: number;
  weight: number;
  maxLoad: number;
  climbAngle: number;
  tireSize: number;
  tireType: "Luftreifen" | "Tubeless" | "Vollgummi";
  suspension: "Keine" | "Vorderrad" | "Hinterrad" | "Vollfederung" | "Hydraulisch";
  brakes: string;
  abs: boolean;
  dimensions: string;
  foldedDimensions: string;
  deckLength: number;
  handlebarHeight: number;
  sizeClass: "kompakt" | "klein" | "mittel" | "groß";
  lights: boolean;
  indicators: boolean;
  brakeLight: boolean;
  display: boolean;
  app: boolean;
  bluetooth: boolean;
  nfc: boolean;
  horn: boolean;
  usb: boolean;
  cruiseControl: boolean;
  alarm: boolean;
  waterproofRating: string;
  abe: boolean;
  availableVersions: VersionKey[];
  useCases: string[];
  rating: {
    overall: number;
    performance: number;
    range: number;
    comfort: number;
    quality: number;
    value: number;
    features: number;
  };
  pros: string[];
  cons: string[];
  verified: boolean;
}

export const DISCLAIMER =
  "Datenstand 18.08.2026. Preise sind Momentaufnahmen und können sich ändern. Reichweiten sind Herstellerangaben unter Testbedingungen und nicht mit einer realen Reichweite gleichzusetzen. Versionen und Zulassungen immer anhand der konkreten deutschen Modellvariante prüfen.";

export const USE_CASES = [
  "Stadt", "Pendeln", "Alltag", "Offroad", "Gelände", "Langstrecke",
  "Performance", "Racing", "Freizeit", "Hügel / Berge",
];

const slug = (s: string) =>
  s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

type RealInput = {
  brand: string; model: string; price: number; year?: number;
  sourceUrl: string; sourceName: string; priceNote?: string;
  speed: number; range: number; voltage: number; ah: number; wh: number;
  rated: number; peak: number; motors?: number; weight: number; load: number;
  climb: number; tire: number; tireType?: Scooter["tireType"];
  suspension: Scooter["suspension"]; brakes: string; abs?: boolean;
  charge: number; dimensions?: string; folded?: string; deck?: number;
  handlebar?: number; indicators?: boolean; display?: boolean; app?: boolean;
  bluetooth?: boolean; nfc?: boolean; horn?: boolean; usb?: boolean;
  cruise?: boolean; alarm?: boolean; waterproof?: string; fast?: boolean;
  removable?: boolean; lights?: boolean; brakeLight?: boolean; abe?: boolean;
  openSpeed?: number | null; usSpeed?: number | null;
  useCases: string[]; pros: string[]; cons: string[];
};

function makeScooter(x: RealInput): Scooter {
  const motors = x.motors ?? 1;
  const speed = x.speed;
  const range = x.range;
  const weight = x.weight;
  const performance = Math.min(5, 3.1 + x.peak / 1800);
  const rangeScore = Math.min(5, 3 + range / 65);
  const comfort = x.suspension === "Hydraulisch" ? 4.9 : x.suspension === "Vollfederung" ? 4.6 : x.suspension === "Vorderrad" ? 3.9 : 3.2;
  const quality = x.price >= 1200 ? 4.6 : x.price >= 700 ? 4.2 : 3.9;
  const value = Math.min(5, Math.max(3, 4.9 - x.price / 1800));
  const features = [x.indicators, x.display, x.app, x.bluetooth, x.nfc, x.usb, x.cruise, x.alarm].filter(Boolean).length;
  const featureScore = Math.min(5, 3 + features * 0.3);
  const overall = Math.round(((performance + rangeScore + comfort + quality + value + featureScore) / 6) * 10) / 10;

  const abe = !!x.abe;
  const availableVersions: VersionKey[] = abe ? ["abe", "eu", "free"] : ["eu", "free"];

  return {
    id: slug(`${x.brand} ${x.model}`), brand: x.brand, model: x.model, name: `${x.brand} ${x.model}`,
    year: x.year ?? 2026, price: x.price, image: "", sourceUrl: x.sourceUrl, sourceName: x.sourceName,
    dataChecked: "18.08.2026", priceNote: x.priceNote ?? "Beobachteter Preis, kann sich ändern.",
    topSpeed: { abe: abe ? 20 : null, eu: speed, us: x.usSpeed ?? null, free: x.openSpeed ?? speed },
    motorPower: { abe: abe ? Math.min(500, x.rated) : null, eu: x.rated, us: x.rated, free: x.rated },
    peakPower: x.peak, motors, range, batteryVoltage: x.voltage, batteryAh: x.ah, batteryWh: x.wh,
    removableBattery: x.removable ?? false, fastCharge: x.fast ?? false, chargingTime: x.charge,
    weight, maxLoad: x.load, climbAngle: x.climb, tireSize: x.tire ?? 10,
    tireType: x.tireType ?? "Tubeless", suspension: x.suspension, brakes: x.brakes, abs: x.abs ?? false,
    dimensions: x.dimensions ?? "Nicht angegeben", foldedDimensions: x.folded ?? "Nicht angegeben",
    deckLength: x.deck ?? 50, handlebarHeight: x.handlebar ?? 120,
    sizeClass: weight < 18 ? "kompakt" : weight < 23 ? "klein" : weight < 31 ? "mittel" : "groß",
    lights: x.lights ?? true, indicators: x.indicators ?? false, brakeLight: x.brakeLight ?? true,
    display: x.display ?? true, app: x.app ?? false, bluetooth: x.bluetooth ?? false,
    nfc: x.nfc ?? false, horn: x.horn ?? false, usb: x.usb ?? false, cruiseControl: x.cruise ?? false,
    alarm: x.alarm ?? false, waterproofRating: x.waterproof ?? "Nicht angegeben", abe,
    availableVersions, useCases: x.useCases,
    rating: { overall, performance: Math.round(performance * 10) / 10, range: Math.round(rangeScore * 10) / 10,
      comfort, quality, value: Math.round(value * 10) / 10, features: Math.round(featureScore * 10) / 10 },
    pros: x.pros, cons: x.cons, verified: true,
  };
}

export const SCOOTERS: Scooter[] = [
  makeScooter({
    brand: "Segway-Ninebot", model: "MAX G3 D", price: 869, sourceUrl: "https://de-de.segway.com/ekickscooter/products/max-g3-d.html",
    sourceName: "Segway Deutschland", speed: 20, range: 80, voltage: 46.8, ah: 12.76, wh: 597,
    rated: 500, peak: 2000, weight: 24.6, load: 130, climb: 30, tire: 11, suspension: "Hydraulisch",
    brakes: "Doppelkolben-Scheibenbremsen vorne + hinten", abs: false, charge: 3.5,
    dimensions: "121,8 × 59,0 × 129,9 cm", folded: "121,8 × 59,0 × 59,2 cm",
    indicators: true, display: true, app: true, bluetooth: true, usb: false, cruise: true, alarm: true, waterproof: "IPX6",
    fast: true, openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Alltag","Langstrecke","Hügel / Berge"],
    pros: ["80 km Herstellerreichweite bei 15 km/h","Hydraulische Doppelfederung","597-Wh-Akku"],
    cons: ["24,6 kg","Herstellerreichweite unter Idealbedingungen"], priceNote: "Marktpreis-Beobachtung; Herstellerseite zeigt aktuell Kauf/Bestelloption.",
  }),
  makeScooter({
    brand: "Segway-Ninebot", model: "ZT3 Pro D", price: 729, sourceUrl: "https://de-de.segway.com/ekickscooter/products/zt3-pro-d.html",
    sourceName: "Segway Deutschland", speed: 20, range: 70, voltage: 46.8, ah: 12.76, wh: 597,
    rated: 500, peak: 1600, weight: 29.7, load: 120, climb: 25, tire: 11, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 4,
    dimensions: "124,5 × 63,8 × 134,0 cm", folded: "124,5 × 63,8 × 64,5 cm",
    indicators: true, display: true, app: true, bluetooth: true, cruise: true, alarm: true, waterproof: "IPX5",
    openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Offroad","Gelände","Hügel / Berge"],
    pros: ["11-Zoll All-Road-Reifen","1600 W Maximalleistung","TCS und SegRide"],
    cons: ["29,7 kg","Reichweite bei 20 km/h laut Hersteller nur ca. 56 km"],
  }),
  makeScooter({
    brand: "Xiaomi", model: "Electric Scooter 5", price: 399.99, sourceUrl: "https://www.mi.com/de/product/xiaomi-electric-scooter-5/specs/",
    sourceName: "Xiaomi Deutschland", speed: 20, range: 60, voltage: 46.8, ah: 10.2, wh: 477,
    rated: 350, peak: 700, weight: 20.1, load: 120, climb: 18, tire: 10, suspension: "Vollfederung",
    brakes: "Trommelbremse + E-ABS", abs: true, charge: 9,
    dimensions: "Nicht angegeben", folded: "Nicht angegeben", indicators: true, display: true, app: true, bluetooth: true,
    cruise: false, waterproof: "IPX5", openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Alltag"],
    pros: ["477 Wh Akku","20,1 kg","60 km Herstellerreichweite"],
    cons: ["Ca. 9 h Standard-Ladezeit","Reichweite bei 15 km/h gemessen"],
  }),
  makeScooter({
    brand: "Xiaomi", model: "Electric Scooter 5 Pro", price: 499.99, sourceUrl: "https://www.mi.com/de/",
    sourceName: "Xiaomi Deutschland / Händlerdaten", speed: 20, range: 60, voltage: 46.8, ah: 10.2, wh: 477,
    rated: 400, peak: 1000, weight: 22.4, load: 120, climb: 22, tire: 10, suspension: "Vollfederung",
    brakes: "Trommelbremse vorne + E-ABS hinten", abs: true, charge: 9,
    dimensions: "119,2 × 58,6 × 127,1 cm", folded: "126,5 × 22,4 × 60,0 cm",
    indicators: true, display: true, app: true, bluetooth: true, cruise: false, alarm: true, waterproof: "IPX5",
    openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Alltag","Langstrecke"],
    pros: ["Doppelfederung","477 Wh","App und Blinker"],
    cons: ["22,4 kg","Lange Standard-Ladezeit"],
  }),
  makeScooter({
    brand: "Xiaomi", model: "Electric Scooter 5 Max", price: 599.99, sourceUrl: "https://www.mi.com/de/product/xiaomi-electric-scooter-5-max/specs/",
    sourceName: "Xiaomi Deutschland", speed: 20, range: 60, voltage: 46.8, ah: 10.2, wh: 477,
    rated: 400, peak: 1000, weight: 22.3, load: 120, climb: 22, tire: 10, suspension: "Hydraulisch",
    brakes: "Trommelbremse + E-ABS", abs: true, charge: 9,
    dimensions: "Nicht angegeben", folded: "Nicht angegeben", indicators: true, display: true, app: true, bluetooth: true,
    cruise: false, waterproof: "IPX5", openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Alltag","Langstrecke"],
    pros: ["Hydraulische Doppelfederung","477 Wh","60 km Herstellerreichweite"],
    cons: ["22,3 kg","Standard-Ladezeit ca. 9 h"],
  }),
  makeScooter({
    brand: "NAVEE", model: "GT5 Max", price: 629, sourceUrl: "https://eu.naveetech.com/en-pl/products/navee-gt5-max",
    sourceName: "NAVEE Europe", speed: 25, range: 90, voltage: 46.8, ah: 12.75, wh: 596.7,
    rated: 700, peak: 1638, weight: 24.8, load: 130, climb: 28, tire: 10, suspension: "Vollfederung",
    brakes: "Vordere Trommelbremse + hintere Scheibenbremse + EABS", abs: true, charge: 5.5,
    dimensions: "119,8 × 60,0 × 128,0 cm", folded: "119,8 × 61,0 × 58,0 cm",
    indicators: true, display: true, app: true, bluetooth: true, cruise: true, waterproof: "IPX5",
    openSpeed: 25, usSpeed: 32, abe: false, useCases: ["Stadt","Pendeln","Alltag","Langstrecke","Hügel / Berge"],
    pros: ["596,7 Wh","90 km bei 15 km/h","TCS und Apple Find My"],
    cons: ["25 km/h EU-Version ist in Deutschland nicht regulär als ABE-Version zugelassen","24,8 kg"],
  }),
  makeScooter({
    brand: "NAVEE", model: "XT5 Ultra", price: 1699, sourceUrl: "https://eu.naveetech.com/pages/compare",
    sourceName: "NAVEE Europe", speed: 25, range: 90, voltage: 46.8, ah: 19.21, wh: 899,
    rated: 1000, peak: 4400, motors: 2, weight: 38.6, load: 150, climb: 45, tire: 12, tireType: "Tubeless",
    suspension: "Hydraulisch", brakes: "Scheibenbremsen vorne + hinten + EABS", abs: true, charge: 4,
    dimensions: "Nicht angegeben", folded: "Nicht angegeben", indicators: true, display: true, app: true, bluetooth: true,
    cruise: true, waterproof: "IPX5", fast: true, openSpeed: 25, usSpeed: 32, abe: false,
    useCases: ["Offroad","Gelände","Performance","Racing","Hügel / Berge","Langstrecke"],
    pros: ["899 Wh","Dualmotor","45 % maximale Steigung","12-Zoll-Offroad-Tubeless"],
    cons: ["38,6 kg","Keine deutsche ABE-Version in den hier geprüften Daten"],
    priceNote: "Preis ist eine Markt-/Richtwertangabe; vor Kauf aktuellen NAVEE-Preis prüfen.",
  }),
  makeScooter({
    brand: "VMAX", model: "VX4 GT", price: 1499, sourceUrl: "https://www.vmax-escooter.de/products/vx4",
    sourceName: "VMAX Deutschland", speed: 20, range: 100, voltage: 48, ah: 23.2, wh: 1113.6,
    rated: 500, peak: 1600, weight: 29, load: 150, climb: 33, tire: 10, tireType: "Tubeless",
    suspension: "Vollfederung", brakes: "Trommelbremse vorne + elektronische Rekuperation hinten", abs: false, charge: 12,
    dimensions: "130,7 × 58,4 × 122,0 cm", folded: "57 × 58,4 × 122,0 cm",
    indicators: true, display: true, app: false, bluetooth: false, usb: true, cruise: true, waterproof: "IPX6",
    fast: false, openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Alltag","Langstrecke","Hügel / Berge"],
    pros: ["1113,6 Wh in GT-Konfiguration","150 kg Zuladung","33 % Steigung"],
    cons: ["29 kg","100 km nur unter Idealbedingungen"],
  }),
  makeScooter({
    brand: "Joyor", model: "S5", price: 419, sourceUrl: "https://joyor.com/collections/eu-e-scooters",
    sourceName: "Joyor Official", speed: 20, range: 45, voltage: 48, ah: 13, wh: 624,
    rated: 500, peak: 1000, weight: 22.5, load: 120, climb: 25, tire: 10, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 8, indicators: true, display: true, app: true, bluetooth: true,
    waterproof: "IP54", openSpeed: 20, abe: true, useCases: ["Stadt","Pendeln","Alltag","Freizeit"],
    pros: ["ABE-Version","624 Wh","Preisgünstig"],
    cons: ["Reichweite 45 km Herstellerangabe","Gewicht über 20 kg"],
  }),
  makeScooter({
    brand: "Joyor", model: "Y8-S", price: 449, sourceUrl: "https://joyor.com/products/joyor-y8-s-abe-electric-scooter",
    sourceName: "Joyor Official", speed: 20, range: 100, voltage: 48, ah: 26, wh: 1248,
    rated: 500, peak: 1000, weight: 24.5, load: 120, climb: 20, tire: 10, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 11.5, indicators: true, display: true, app: true, bluetooth: true,
    waterproof: "IP54", openSpeed: 20, abe: true, useCases: ["Pendeln","Alltag","Langstrecke","Hügel / Berge"],
    pros: ["26 Ah Akku","75–100 km Herstellerangabe","ABE"],
    cons: ["24,5 kg","Hersteller nennt eine Reichweitenspanne"],
  }),
  makeScooter({
    brand: "Joyor", model: "S5 Pro", price: 529, sourceUrl: "https://joyor.com/products/joyor-s5-pro-abe-electric-scooter",
    sourceName: "Joyor Official", speed: 20, range: 90, voltage: 48, ah: 26, wh: 1248,
    rated: 500, peak: 1000, weight: 25.7, load: 120, climb: 20, tire: 10, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 13, indicators: true, display: true, app: true, bluetooth: true,
    waterproof: "IP54", openSpeed: 20, abe: true, useCases: ["Pendeln","Alltag","Langstrecke","Hügel / Berge"],
    pros: ["1248 Wh","90 km Herstellerreichweite","ABE"],
    cons: ["25,7 kg","Lange Ladezeit"],
  }),
  makeScooter({
    brand: "Joyor", model: "T6E Pro", price: 579, sourceUrl: "https://joyor.com/products/joyor-t6e-pro-abe-electric-scooter",
    sourceName: "Joyor Official", speed: 20, range: 90, voltage: 48, ah: 26, wh: 1248,
    rated: 500, peak: 1000, weight: 27.5, load: 148, climb: 20, tire: 10, suspension: "Vollfederung",
    brakes: "Hydraulische Bremsen vorne + hinten", abs: false, charge: 14, indicators: true, display: true, app: true, bluetooth: true,
    waterproof: "IPX5", openSpeed: 20, abe: true, useCases: ["Pendeln","Alltag","Langstrecke","Hügel / Berge","Gelände"],
    pros: ["148 kg Zuladung","1248 Wh","Hydraulische Bremsen"],
    cons: ["27,5 kg","14 h Ladezeit laut Hersteller"],
  }),
  makeScooter({
    brand: "Joyor", model: "S10-S-Z", price: 609, sourceUrl: "https://joyor.com/products/joyor-s10-s-z-electric-scooter",
    sourceName: "Joyor Official", speed: 25, range: 75, voltage: 60, ah: 18, wh: 1080,
    rated: 2000, peak: 2000, motors: 2, weight: 29.8, load: 120, climb: 25, tire: 10, suspension: "Vollfederung",
    brakes: "Hydraulische Bremsen vorne + hinten", abs: false, charge: 9, indicators: true, display: true, app: false, bluetooth: false,
    waterproof: "IP54", openSpeed: 25, abe: false, useCases: ["Offroad","Gelände","Performance","Hügel / Berge"],
    pros: ["2 × 1000 W Motor","60 V / 18 Ah","Hydraulische Bremsen"],
    cons: ["Keine ABE in der geprüften EU-Version","29,8 kg"],
  }),
  makeScooter({
    brand: "Joyor", model: "T6E", price: 519, sourceUrl: "https://joyor.com/collections/eu-e-scooters",
    sourceName: "Joyor Official", speed: 20, range: 70, voltage: 48, ah: 18, wh: 864,
    rated: 500, peak: 1000, weight: 25, load: 120, climb: 20, tire: 10, suspension: "Vollfederung",
    brakes: "Scheibenbremsen vorne + hinten", abs: false, charge: 10, indicators: true, display: true, app: true, bluetooth: true,
    waterproof: "IP54", openSpeed: 20, abe: true, useCases: ["Pendeln","Alltag","Langstrecke"],
    pros: ["864 Wh","70 km Herstellerreichweite","ABE"],
    cons: ["25 kg","Längere Ladezeit"],
  }),
];

export const BRANDS = [...new Set(SCOOTERS.map(s => s.brand))].map(name => ({
  name, slug: slug(name),
  country: name === "Xiaomi" ? "China" : name === "NAVEE" ? "China" : name === "VMAX" ? "Schweiz" : name === "Segway-Ninebot" ? "USA / China" : "Spanien",
  count: SCOOTERS.filter(s => s.brand === name).length,
  priceFrom: Math.min(...SCOOTERS.filter(s => s.brand === name).map(s => s.price)),
})).sort((a,b) => a.name.localeCompare(b.name));

export const byId = (id: string) => SCOOTERS.find(s => s.id === id);
export const brandBySlug = (s: string) => BRANDS.find(b => b.slug === s);
export const speedFor = (s: Scooter, v: VersionKey) => s.topSpeed[v];
export const powerFor = (s: Scooter, v: VersionKey) => s.motorPower[v];
export const fmtPrice = (p: number) => `${p.toLocaleString("de-DE", { minimumFractionDigits: p % 1 ? 2 : 0, maximumFractionDigits: 2 })} €`;
export const fmt = (v: number | null | undefined, unit = "") => v == null ? "Nicht bekannt" : `${v}${unit ? " " + unit : ""}`;
export const valueScore = (s: Scooter) => Math.round(((s.range * 1.5 + (s.topSpeed.free ?? 20) * 2 + (s.motorPower.free ?? 0) / 20) / s.price) * 1000);

export const CATEGORIES = [
  { slug: "stadt", label: "🏙️ Beste E-Scooter für die Stadt", filter: (s: Scooter) => s.useCases.includes("Stadt"), sort: (a: Scooter,b: Scooter) => b.rating.overall-a.rating.overall },
  { slug: "pendler", label: "🛣️ Beste E-Scooter für Pendler", filter: (s: Scooter) => s.useCases.includes("Pendeln"), sort: (a: Scooter,b: Scooter) => b.rating.overall-a.rating.overall },
  { slug: "offroad", label: "🏕️ Beste Offroad-E-Scooter", filter: (s: Scooter) => s.useCases.includes("Offroad"), sort: (a: Scooter,b: Scooter) => b.peakPower-a.peakPower },
  { slug: "schnell", label: "⚡ Schnellste E-Scooter", filter: () => true, sort: (a: Scooter,b: Scooter) => (b.topSpeed.free??0)-(a.topSpeed.free??0) },
  { slug: "leistung", label: "💪 Leistungsstärkste E-Scooter", filter: () => true, sort: (a: Scooter,b: Scooter) => b.peakPower-a.peakPower },
  { slug: "reichweite", label: "🔋 Größte Reichweite", filter: () => true, sort: (a: Scooter,b: Scooter) => b.range-a.range },
  { slug: "unter-500", label: "💰 Beste E-Scooter unter 500 €", filter: s => s.price < 500, sort: (a: Scooter,b: Scooter) => b.rating.overall-a.rating.overall },
  { slug: "preis-leistung", label: "🔥 Bestes Preis-Leistungs-Verhältnis", filter: () => true, sort: (a: Scooter,b: Scooter) => valueScore(b)-valueScore(a) },
  { slug: "leicht", label: "🪶 Leichte E-Scooter", filter: s => s.weight <= 18, sort: (a: Scooter,b: Scooter) => a.weight-b.weight },
  { slug: "premium", label: "🏆 Premium E-Scooter", filter: s => s.price >= 1000, sort: (a: Scooter,b: Scooter) => b.rating.overall-a.rating.overall },
  { slug: "abe", label: "🇩🇪 Beste E-Scooter mit ABE", filter: s => s.abe, sort: (a: Scooter,b: Scooter) => b.rating.overall-a.rating.overall },
];
